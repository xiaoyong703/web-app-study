<!DOCTYPE html>
<html>
<head>
    <title>Debug Test</title>
</head>
<body>
    <h1>Debug Test Page</h1>
    <p>If you can see this page, then navigation is working.</p>
    <p>Current time: <?php echo date('Y-m-d H:i:s'); ?></p>
    <p><a href="../index.php">Back to Home</a></p>
    <p><a href="login.php">Go to Login</a></p>
</body>
</html>