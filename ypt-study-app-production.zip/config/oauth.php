<?php
// Google OAuth configuration
define('GOOGLE_CLIENT_ID', '707730920463-tf7svsd22kt8jh5jjsq9llp4ti1lchd9.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'https://xynotoky.online/api/auth/google-callback.php');

// GitHub OAuth configuration (optional)
define('GITHUB_CLIENT_ID', 'your_github_client_id_here');
define('GITHUB_CLIENT_SECRET', 'your_github_client_secret_here');
define('GITHUB_REDIRECT_URI', 'https://xynotoky.online/api/auth/github-callback.php');

// Facebook OAuth configuration (optional)
define('FACEBOOK_APP_ID', 'your_facebook_app_id_here');
define('FACEBOOK_APP_SECRET', 'your_facebook_app_secret_here');
define('FACEBOOK_REDIRECT_URI', 'https://xynotoky.online/api/auth/facebook-callback.php');
?>